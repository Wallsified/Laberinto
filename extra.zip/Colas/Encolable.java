/**
 * Interfaz que describe las operaciones sobre colas
 * @author Amparo L&oacute;pez Gaona
 * @version 1a. ed.
 */
public interface Encolable {
    /**
     * Metodo para determinar si una cola esta o no vacia.
     * @return boolean -- true si la cola esta vacia y false en otro caso.
     */
    public boolean estaVacia();

    /**
     * Metodo para eliminar todos los elementos de una cola
     */
    public void vaciar() ;

    /**
     * Metodo para conocer el tamano de una cola
     * @return int -- cantidad de elementos en la cola
     */
    public int tamanio() ;

    /**
     * Metodo para introducir un elemento en la cola
     * @param dato -- elemento a introducir en la cola
     */
    public void agregar(Object dato) ;

    /**
     * Metodo para obtener el elemento del frente de la cola, sin alterar esta
     * @return Object -- ultimo elemento en entrar a la cola
     */
    public Object tomar();

    /**
     * Metodo para eliminar el elemento del frente de la cola
     */
    public void eliminar() ;

    /**
     * Metodo para obtener un iterador sobre la cola
     * @return Iterator -- iterador sobre la cola
     */
    public java.util.Iterator iterador();
}
