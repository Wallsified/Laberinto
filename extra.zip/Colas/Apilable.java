public interface Apilable {
    public boolean estaVacia ();
    public void vaciar() ;
    public Object top() ;
    public Object pop() ;
    public void push(Object x) ;
    public java.util.Iterator iterador();
}
