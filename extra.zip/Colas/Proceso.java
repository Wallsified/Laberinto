/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/** 
  Clase auxiliar para probar los procesos en el RoundRobin
**/

public class Proceso{
    private String nombre;
    private int IdProc;
    private int tiempo;
    private int prioridad;
    private boolean estado;

    public Proceso(String nombre, int tiempo){
        asignarNombre(nombre);
        asignarTiempo(tiempo);
        //estado cuando se crea un proceso siempre va a estar activo
        asignarEstado(true);
	prioridad = 0;
    }

    public Proceso(String nombre, int tiempo, int p){
        asignarNombre(nombre);
        asignarTiempo(tiempo);
        //estado cuando se crea un proceso siempre va a estar activo
        asignarEstado(true);
	prioridad = p;
    }
    
    public String obtenerNombre() {
        return nombre;
    }

    public void asignarNombre(String nmbre) {
        nombre = nmbre;
    }

    public int obtenerIdProc() {
        return IdProc;
    }

    public void asignarIdProc(int Id) {
        IdProc = Id;
    }

    public int obtenerTiempo() {
        return tiempo;
    }

    public void asignarTiempo(int t) {
        tiempo = t;
    }


    public int obtenerPrioridad() {
        return prioridad;
    }

    public void asignarPrioridad(int p) {
        prioridad = p;
    }

    public boolean isEstado() {
        return estado;
    }

    public void asignarEstado(boolean edo) {
        estado = edo;
    }
}

/** Determina el proceso que tiene mayor prioridad y en caso de empate, el que
 * tenga mayor duracion
 */
class ComparaProcesos implements java.util.Comparator {
    public int compare(Object o1, Object o2) {
	if (o1 == o2)  return 0;
	if(o1 == null) return -1;
	if(o2 == null) return 1;
	Proceso oo1 = (Proceso)o1;
	Proceso oo2 = (Proceso)o2;

	int difPromedio = oo2.obtenerPrioridad() - oo1.obtenerPrioridad();
	return (difPromedio == 0) ? oo2.obtenerTiempo() - oo1.obtenerTiempo()
	    : difPromedio;
    }
}
