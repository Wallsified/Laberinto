/** 
 * Programa que recorree un arbol por niveles. Usa una cola para almacenar 
 * los elementos visitados.
 * @author Amparo L�pez Gaona
 * @version Noviembre 2004

 * Para probarlo en un m�todo imprime poner este cuerpo:
	OrdenPorNivel e = new OrdenPorNivel(raiz);
	while(e.hasNext()) 
	    System.out.print(e.next()+" ");
*/
class OrdenPorNivel implements java.util.Iterator {
    private Cola c = new Cola();

    public OrdenPorNivel (NodoArbol raiz) {
	c.agregar(raiz);
    }

    public boolean hasNext() {
	return ! c.est�Vac�a();
    }

    public Object next() {
	NodoArbol actual = (NodoArbol) c.tomar();
	c.eliminar();  //Revisar esto con mi codigo de la fac. abril'09
	if (actual.izquierda != null)
	    c.agregar(actual.izquierda);
	if (actual.derecha != null)
	    c.agregar(actual.derecha);
	return actual.valor;
    }
    public void remove () {
	throw new IllegalStateException();
    }
}
