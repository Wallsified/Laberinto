/**
 * Clase que implementa el TAD Cola usando nodos ligados
 * @author Amparo L�pez Gaona
 * @version 1a. ed.
 */
public class Cola implements Encolable{
    protected Nodo inicio;   // Nodo del inicio de la cola
    protected Nodo fin;      // Nodo del final de la cola
    protected int nDatos;    // Cantidad de datos en la cola

    /**  
     *Constructor por omision. Construye la cola  
     */
    public Cola() {
	inicio = null;
	fin = null;
	nDatos = 0;
    }

    /** 
     * Metodo para determinar si la cola esta vacia o no.
     * @return boolean -- true si esta vacia y false en otro caso.
     */
    public boolean estaVacia() {
	return inicio == null;
    }


    /**
     * Metodo para dejar la cola vac�a.  
     */
    public void vaciar() {
	inicio = fin = null;
	nDatos = 0;
    }

    /**
     * Metodo para conocer el tamano de una pila
     * @return int -- cantidad de elementos en la pila
     */
    public int tamanio() {
	return nDatos;
    }

    /** 
     * Metodo para insertar un elemento en la cola
     * @param dato - elemento que ser� insertado
     */
    public void agregar(Object dato) {
	if (inicio == null)
	    inicio = fin = new Nodo(dato);
	else {
	    Nodo temp = new Nodo(dato);
	    fin.sgte = temp;
	    fin = temp;
	}
	nDatos++;
    }

    /**
     * Metodo para obtener el primer elemento de la cola sin alterar esta
     * @return Object - elemento del inicio de la cola
     */
    public Object tomar() {
	return (inicio == null) ? null : inicio.elemento;
    }

    /**
     * Metodo para eliminar el primer elemento de la cola  
     */
    public void eliminar() {
	if (inicio != null)
	    inicio = inicio.sgte;
	nDatos--;
    }

    /**
     * Metodo para obtener un iterador sobre la cola
     * @return Iterator -- iterador sobre la cola
     */
    public java.util.Iterator iterador() { 
	return new MiIterador(); 
    }

    private class MiIterador implements java.util.Iterator {
	private Nodo posicion = inicio;

	public boolean hasNext() { return posicion != null;}

	public Object next() {
	    if (hasNext()) {
		Object o = posicion.elemento;
		posicion = posicion.sgte;
		return o;
	    }
	    return null;
	}

	public void remove()         {
	    throw new IllegalStateException();
	}
    }
}
