/**
 * Clase para acomodar los vagones de un tren en orden secuencial,
 * utilizando colas
 * @author ALG
 * @version 1a. ed.
 */
public class Trenes {
    private Cola[] pista;           // Pista para maniobras
    private int nVagones;           // Cantidad de vagones del tren
    private int nPistas;            // Cantidad de pistas para maniobras
    private int[] ordenInicial;     // Orden inicial de los vagones
    private int[] ultimoVgnEnCola;  // Ultimo vagon en cada pista

    /**
     * Constructor que toma el orden  de los vagones antes del reacomodo y 
     * la cantidad de pistas para maniobras.
     * @param ordenIni -- arreglo de enteros en que se especifica el orden
       inicial de los vagones.
     * @param numPistas -- cantidad de pistas en el area de maniobras
     */
    public Trenes (int[] ordenIni, int numPistas) {
	nVagones = ordenIni.length;
	nPistas = numPistas;

	pista = new Cola[nPistas + 1];
	for (int i = 1; i <= nPistas; i++)
	    pista[i] = new Cola();
	ultimoVgnEnCola = new int[nPistas + 1];

	ordenInicial = new int[ordenIni.length];
	for (int i= 0; i < ordenInicial.length; i++)
	    ordenInicial[i] = ordenIni[i];
    }

    /** 
     * Constructor por omision. 
     */
    public Trenes() {
	this(new int [] {3,6,9,2,4,7,1,8,5}, 3); 
	//	this(new int [] {5,8,1,7,4,2,9,6,3}, 3);  NO tiene solucion
    }

    /** 
     *  Metodo para acomodar los vagones del tren
     *  @return boolean - devuelve true si es posible acomodarlos y false
     *  en otro caso.
     */
    public boolean acomodarVagones() {
	int sgteVagonFuera = 1;

	for (int i = 0; i < nVagones; i++){
	    if (ordenInicial[i] == sgteVagonFuera) { // Saca el vagon
		System.out.println("Mueve el vagon " + ordenInicial[i] +
				   "de la pista de entrada a la salida");
		sgteVagonFuera++;
		while (sacarDeAreaM(sgteVagonFuera)) 
		            // Verifica que pueden sacar otros del area de maniobras
		    sgteVagonFuera++;
	    } else if (!colocarEnAreaM(ordenInicial[i]))
		return false;
	}
	return true;
    }

    /* Metodo privado para sacar un vagor del area de maniobras 
   * @param vagon -- vagon que se va a sacar
   * @return boolean -- devuelve true si lo puede sacar y false en otro caso
   **/
    private boolean sacarDeAreaM(int vagon) {
	for (int i = 1; i < nPistas; i++) 
	    if (!pista[i].estaVacia() &&
		((Integer) pista[i].tomar()).intValue() == vagon) {
		pista[i].eliminar();
		System.out.println("Mueve el vagon "+ vagon + " del campo de "
				   +"maniobra "+ i + " a la salida");
		if(pista[i].estaVacia()) 
		    ultimoVgnEnCola[i] = 0;
		return true;
	    }
	return false;
    }

    /** 
     *  Metodo para colocar un vagon en el area de maniobras 
     *  @param - numero del vagon que se desea colocar.
     *  @return boolean - devuelve true si es posible colocarlo en alguna
     *  de las pistas y false en otro caso
     **/
    public boolean colocarEnAreaM(int vagon) {
	for (int i = 1; i < nPistas; i++)
	    if (pista[i].estaVacia() || vagon > ultimoVgnEnCola[i]) {
		    pista[i].agregar(new Integer(vagon));
		    ultimoVgnEnCola[i] = vagon;
		    System.out.println("Mover el vagon "+ vagon + " de la entrada al "
			   + "area "+ i);
		    return true;
	    }
	return false;  // No hubo lugar
    }

    /**
     * Metodo para probar el acomodo de trenes
     */
    public static void main(String [] pps) {
	Trenes tc = new Trenes();
	if(!tc.acomodarVagones())
	    System.out.println("No es posible acomodar los vagones");
    }
}

